//import { Tab } from "../vendor/bootstrap/js/bootstrap.bundle";
///// <reference path="slimtable.js" />
/*
  SortTable
  version 2
  7th April 2007
  Stuart Langridge, http://www.kryogenix.org/code/browser/sorttable/

  Instructions:
  Download this file
  Add <script src="sorttable.js"></script> to your HTML
  Add class="sortable" to any table you'd like to make sortable
  Click on the headers to sort

  Thanks to many, many people for contributions and suggestions.
  Licenced as X11: http://www.kryogenix.org/code/browser/licence.html
  This basically means: do what you want with it.
*/



//<script>
function pagination(_tableId, _selectedPageNo, _recordPerPage, _createNew) {
    var tableId = "#" + _tableId;
    var recordPerPage = _recordPerPage;
    var elementTable = $(tableId);
    //alert(recordPerPage);
    var totalRows = elementTable.find('tbody tr:has(td)').length;
    //var recordPerPage = 5;
    var $pages = $($(elementTable.parent()).find("#pages"));//$($(elementTable.parent()).find("#pages")).length
    //debugger;
    if (_createNew == 'true') {//(totalRows > recordPerPage || $pages.length > 0) && !_selectedPageNo
        $pages.remove();
    }
    var totalPages = Math.ceil(totalRows / recordPerPage);

    if (($pages.length == 0 && totalPages > 1) || _createNew == 'true') {//
        $pages = $('<div id="pages" class="pagination-container"></div>');
        var $pageOption = $('<div class="pagination-option">Show ' +
            '<select id="ddlPagination">' +
            '<option value="10">10</option><option value="20">20</option><option value="50">50</option><option value="100">100</option><option value="1000">All</option></select>' +
            'entries</div>');
        $pageOption.appendTo($pages);


        var $pageNumbers = $('<div id="paginationNumbers" class="pagination-Numbers"></div>');
        for (i = 0; i < totalPages; i++) {
            if (i == 0)
                $('<span class="pageNumber active">' + (i + 1) + '</span>').appendTo($pageNumbers);//&nbsp;
            else
                $('<span class="pageNumber">' + (i + 1) + '</span>').appendTo($pageNumbers);
        }
        $pageNumbers.appendTo($pages);
        $pages.appendTo(elementTable.parent());
    }

    var $paginationSelection = $pages.find("select");
    $paginationSelection.val('' + recordPerPage + '');

    //elementTable.find('tbody tr:has(td)').hide();
    var tr = $(elementTable.find('tbody tr:has(td)'));
    tr.hide();
    for (var i = 0; i <= recordPerPage - 1; i++) {
        $(tr[i]).show();
    }


    $paginationSelection.change(function (event) {
        //$("input[name*='gridsortable']").val()
        var recordsPerPage = $(this).val();
        pagination(_tableId, '', recordsPerPage, 'true');
        gridPaginationSorting(_tableId, '', recordsPerPage, '', '');
    });


    $($pages.find('#paginationNumbers').find('span')).click(function (event) {
        elementTable.find('tbody tr:has(td)').hide();
        var nBegin = ($(this).text() - 1) * recordPerPage;
        var nEnd = $(this).text() * recordPerPage - 1;
        for (var i = nBegin; i <= nEnd; i++) {
            $(tr[i]).show();
        }
        elementTable.parent().find('span').removeClass('active');
        $(this).addClass('active');

        var pageNumber = $(this).text();
        var recordsPerPage = $paginationSelection.val();

        gridPaginationSorting(_tableId, pageNumber, recordsPerPage, '', '');
    });

    if (_selectedPageNo.trim()) {
        $($pages.find('#paginationNumbers').find('span')).each(function (i) {
            if (this.innerText.trim() == _selectedPageNo.trim()) {
                //debugger;
                this.click();
                //    this.classList.add("active");
            }
            //else {
            //    this.classList.remove("active");
            //}
        })
    }

    //$('span').click(function (event) {
    //    elementTable.find('tbody tr:has(td)').hide();
    //    var nBegin = ($(this).text() - 1) * recordPerPage;
    //    var nEnd = $(this).text() * recordPerPage - 1;
    //    for (var i = nBegin; i <= nEnd; i++) {
    //        $(tr[i]).show();
    //    }
    //    elementTable.parent().find('span').removeClass('active');
    //    $(this).addClass('active');
    //});

}



//--------------------------------------------






var stIsIE = false;
sorttable = {
    init: function () {
        // quit if this function has already been called
        if (arguments.callee.done) return;
        // flag this function so we don't do the same thing twice
        arguments.callee.done = true;
        // kill the timer
        if (_timer) clearInterval(_timer);

        if (!document.createElement || !document.getElementsByTagName) return;

        sorttable.DATE_RE = /^(\d\d?)[\/\.-](\d\d?)[\/\.-]((\d\d)?\d\d)$/;

        forEach(document.getElementsByTagName('table'), function (table) {
            if (table.className.search(/\bsortable\b/) != -1) {
                sorttable.makeSortable(table);
            }
        });

    },

    makeSortable: function (table) {
        if (table.getElementsByTagName('thead').length == 0) {
            // table doesn't have a tHead. Since it should have, create one and
            // put the first table row in it.
            the = document.createElement('thead');
            the.appendChild(table.rows[0]);
            table.insertBefore(the, table.firstChild);
        }
        // Safari doesn't support table.tHead, sigh
        if (table.tHead == null) table.tHead = table.getElementsByTagName('thead')[0];

        if (table.tHead.rows.length != 1) return; // can't cope with two header rows

        // Sorttable v1 put rows with a class of "sortbottom" at the bottom (as
        // "total" rows, for example). This is B&R, since what you're supposed
        // to do is put them in a tfoot. So, if there are sortbottom rows,
        // for backwards compatibility, move them to tfoot (creating it if needed).
        sortbottomrows = [];
        for (var i = 0; i < table.rows.length; i++) {
            if (table.rows[i].className.search(/\bsortbottom\b/) != -1) {
                sortbottomrows[sortbottomrows.length] = table.rows[i];
            }
        }
        if (sortbottomrows) {
            if (table.tFoot == null) {
                // table doesn't have a tfoot. Create one.
                tfo = document.createElement('tfoot');
                table.appendChild(tfo);
            }
            for (var i = 0; i < sortbottomrows.length; i++) {
                tfo.appendChild(sortbottomrows[i]);
            }
            delete sortbottomrows;
        }

        // work through each column and calculate its type
        headrow = table.tHead.rows[0].cells;

        for (var i = 0; i < headrow.length; i++) {
            // manually override the type with a sorttable_type attribute
            if (!headrow[i].className.match(/\bsorttable_nosort\b/)) { // skip this col
                mtch = headrow[i].className.match(/\bsorttable_([a-z0-9]+)\b/);
                if (mtch) { override = mtch[1]; }
                if (mtch && typeof sorttable["sort_" + override] == 'function') {
                    headrow[i].sorttable_sortfunction = sorttable["sort_" + override];
                } else {
                    headrow[i].sorttable_sortfunction = sorttable.guessType(table, i);
                }

                // make it clickable to sort
                headrow[i].sorttable_columnindex = i;
                headrow[i].sorttable_tbody = table.tBodies[0];
                dean_addEvent(headrow[i], "click", sorttable.innerSortFunction = function (e) {
                    sortTableCustom(this, '', '', '', '');
                });
            }
        }
    },

    guessType: function (table, column) {
        // guess the type of a column based on its first non-blank row
        sortfn = sorttable.sort_alpha;
        for (var i = 0; i < table.tBodies[0].rows.length; i++) {
            text = sorttable.getInnerText(table.tBodies[0].rows[i].cells[column]);
            if (text != '') {
                if (text.match(/^-?[�$�]?[\d,.]+%?$/)) {
                    return sorttable.sort_numeric;
                }
                // check for a date: dd/mm/yyyy or dd/mm/yy
                // can have / or . or - as separator
                // can be mm/dd as well
                possdate = text.match(sorttable.DATE_RE)
                if (possdate) {
                    // looks like a date
                    first = parseInt(possdate[1]);
                    second = parseInt(possdate[2]);
                    if (first > 12) {
                        // definitely dd/mm
                        return sorttable.sort_ddmm;
                    } else if (second > 12) {
                        return sorttable.sort_mmdd;
                    } else {
                        // looks like a date, but we can't tell which, so assume
                        // that it's dd/mm (English imperialism!) and keep looking
                        sortfn = sorttable.sort_ddmm;
                    }
                }
            }
        }
        return sortfn;
    },

    getInnerText: function (nodeElement) {
        // gets the text we want to use for sorting for a cell.
        // strips leading and trailing whitespace.
        // this is *not* a generic getInnerText function; it's special to sorttable.
        // for example, you can override the cell text with a customkey attribute.
        // it also gets .value for <input> fields.
        try {
            if (!nodeElement) return "";

            hasInputs = (typeof nodeElement.getElementsByTagName == 'function') &&
                nodeElement.getElementsByTagName('input').length;

            if (nodeElement.getAttribute("sorttable_customkey") != null) {
                return nodeElement.getAttribute("sorttable_customkey");
            }
            else if (typeof nodeElement.textContent != 'undefined' && !hasInputs) {
                return nodeElement.textContent.replace(/^\s+|\s+$/g, '');
            }
            else if (typeof nodeElement.innerText != 'undefined' && !hasInputs) {
                return nodeElement.innerText.replace(/^\s+|\s+$/g, '');
            }
            else if (typeof nodeElement.text != 'undefined' && !hasInputs) {
                return nodeElement.text.replace(/^\s+|\s+$/g, '');
            }
            else {
                switch (nodeElement.nodeType) {
                    case 3:
                        if (nodeElement.nodeName.toLowerCase() == 'input') {
                            return nodeElement.value.replace(/^\s+|\s+$/g, '');
                        }
                    case 4:
                        return nodeElement.nodeValue.replace(/^\s+|\s+$/g, '');
                        break;
                    case 1:
                    case 11:
                        var innerText = '';
                        for (var i = 0; i < nodeElement.childNodes.length; i++) {
                            innerText += sorttable.getInnerText(nodeElement.childNodes[i]);
                        }
                        return innerText.replace(/^\s+|\s+$/g, '');
                        break;
                    default:
                        return '';
                }
            }
        }
        catch (ex) {

        }

    },

    reverse: function (tbody) {
        // reverse the rows in a tbody
        newrows = [];
        for (var i = 0; i < tbody.rows.length; i++) {
            newrows[newrows.length] = tbody.rows[i];
        }
        for (var i = newrows.length - 1; i >= 0; i--) {
            tbody.appendChild(newrows[i]);
        }
        delete newrows;
    },

    /* sort functions
       each sort function takes two parameters, a and b
       you are comparing a[0] and b[0] */
    sort_numeric: function (a, b) {
        aa = parseFloat(a[0].replace(/[^0-9.-]/g, ''));
        if (isNaN(aa)) aa = 0;
        bb = parseFloat(b[0].replace(/[^0-9.-]/g, ''));
        if (isNaN(bb)) bb = 0;
        return aa - bb;
    },
    sort_alpha: function (a, b) {
        if (a[0] == b[0]) return 0;
        if (a[0] < b[0]) return -1;
        return 1;
    },
    sort_ddmm: function (a, b) {
        mtch = a[0].match(sorttable.DATE_RE);
        y = mtch[3]; m = mtch[2]; d = mtch[1];
        if (m.length == 1) m = '0' + m;
        if (d.length == 1) d = '0' + d;
        dt1 = y + m + d;
        mtch = b[0].match(sorttable.DATE_RE);
        y = mtch[3]; m = mtch[2]; d = mtch[1];
        if (m.length == 1) m = '0' + m;
        if (d.length == 1) d = '0' + d;
        dt2 = y + m + d;
        if (dt1 == dt2) return 0;
        if (dt1 < dt2) return -1;
        return 1;
    },
    sort_mmdd: function (a, b) {
        mtch = a[0].match(sorttable.DATE_RE);
        y = mtch[3]; d = mtch[2]; m = mtch[1];
        if (m.length == 1) m = '0' + m;
        if (d.length == 1) d = '0' + d;
        dt1 = y + m + d;
        mtch = b[0].match(sorttable.DATE_RE);
        y = mtch[3]; d = mtch[2]; m = mtch[1];
        if (m.length == 1) m = '0' + m;
        if (d.length == 1) d = '0' + d;
        dt2 = y + m + d;
        if (dt1 == dt2) return 0;
        if (dt1 < dt2) return -1;
        return 1;
    },

    shaker_sort: function (list, comp_func) {
        // A stable sort function to allow multi-level sorting of data
        // see: http://en.wikipedia.org/wiki/Cocktail_sort
        // thanks to Joseph Nahmias
        var b = 0;
        var t = list.length - 1;
        var swap = true;

        while (swap) {
            swap = false;
            for (var i = b; i < t; ++i) {
                if (comp_func(list[i], list[i + 1]) > 0) {
                    var q = list[i]; list[i] = list[i + 1]; list[i + 1] = q;
                    swap = true;
                }
            } // for
            t--;

            if (!swap) break;

            for (var i = t; i > b; --i) {
                if (comp_func(list[i], list[i - 1]) < 0) {
                    var q = list[i]; list[i] = list[i - 1]; list[i - 1] = q;
                    swap = true;
                }
            } // for
            b++;

        } // while(swap)
    }
}

function sortTableCustom(args, _colIndex, _className, _selectedPageNo, _recordPerPage) {
    //debugger;
    if (!_colIndex || _colIndex < 0) {
        _this = args;
    }
    else {
        var headrow = args.tHead.rows[0].cells;
        for (var i = 0; i < headrow.length; i++) {
            // manually override the type with a sorttable_type attribute
            if (!headrow[i].className.match(/\bsorttable_nosort\b/)) { // skip this col
                // make it clickable to sort
                var columnIndex = headrow[i].sorttable_columnindex;
                if (_colIndex == columnIndex) {
                    _this = headrow[i];
                }
                // headrow[i].sorttable_tbody = table.tBodies[0];
            }
        }
    }
    var className = _className;
    if (className) {
        if (className.trim() == 'sorttable_sorted')
            _this.classList.add("sorttable_sorted_reverse");
        else if (className.trim() == 'sorttable_sorted_reverse')
            _this.classList.add("sorttable_sorted");

        //_this.addClass('sorttable_sorted_reverse');
        //_this.addClass('sorttable_sorted');
    }

    //alert(_this.sorttable_columnindex + _this.className);
    if (_this.className.search(/\bsorttable_sorted\b/) != -1) {
        // if we're already sorted by _this column, just
        // reverse the table, which is quicker
        sorttable.reverse(_this.sorttable_tbody);
        _this.className = _this.className.replace('sorttable_sorted', 'sorttable_sorted_reverse');
        //_this.removeChild(document.getElementById('sorttable_sortfwdind'));
        //sortrevind = document.createElement('span');
        //sortrevind.id = "sorttable_sortrevind";
        //sortrevind.innerHTML = stIsIE ? '&nbsp<font face="webdings">5</font>' : '&nbsp;&#x25B4;';
        //_this.appendChild(sortrevind);

        //return;
    }
    else if (_this.className.search(/\bsorttable_sorted_reverse\b/) != -1) {
        // if we're already sorted by _this column in reverse, just
        // re-reverse the table, which is quicker
        sorttable.reverse(_this.sorttable_tbody);
        _this.className = _this.className.replace('sorttable_sorted_reverse', 'sorttable_sorted');
        //_this.removeChild(document.getElementById('sorttable_sortrevind'));
        //sortfwdind = document.createElement('span');
        //sortfwdind.id = "sorttable_sortfwdind";
        //sortfwdind.innerHTML = stIsIE ? '&nbsp<font face="webdings">6</font>' : '&nbsp;&#x25BE;';
        //_this.appendChild(sortfwdind);

        //return;
    }
    else {

        // remove sorttable_sorted classes
        theadrow = _this.parentNode;
        forEach(theadrow.childNodes, function (cell) {
            if (cell.nodeType == 1) { // an element
                cell.className = cell.className.replace('sorttable_sorted_reverse', '');
                cell.className = cell.className.replace('sorttable_sorted', '');
            }
        });
        //sortfwdind = document.getElementById('sorttable_sortfwdind');
        //if (sortfwdind) { sortfwdind.parentNode.removeChild(sortfwdind); }
        //sortrevind = document.getElementById('sorttable_sortrevind');
        //if (sortrevind) { sortrevind.parentNode.removeChild(sortrevind); }

        _this.className += ' sorttable_sorted';
        //sortfwdind = document.createElement('span');
        //sortfwdind.id = "sorttable_sortfwdind";
        //sortfwdind.innerHTML = stIsIE ? '&nbsp<font face="webdings">6</font>' : '&nbsp;&#x25BE;';
        //_this.appendChild(sortfwdind);

        // build an array to sort. _this is a Schwartzian transform thing,
        // i.e., we "decorate" each row with the actual sort key,
        // sort based on the sort keys, and then put the rows back in order
        // which is a lot faster because you only do getInnerText once per row
        row_array = [];
        col = _this.sorttable_columnindex;
        rows = _this.sorttable_tbody.rows;
        for (var j = 0; j < rows.length; j++) {
            row_array[row_array.length] = [sorttable.getInnerText(rows[j].cells[col]), rows[j]];
        }
        /* If you want a stable sort, uncomment the following line */
        //sorttable.shaker_sort(row_array, _this.sorttable_sortfunction);
        /* and comment out _this one */
        row_array.sort(_this.sorttable_sortfunction);

        tb = _this.sorttable_tbody;
        for (var j = 0; j < row_array.length; j++) {
            tb.appendChild(row_array[j][1]);
        }

        delete row_array;

    }

    //alert(table.id);
    var tableId = $(_this).closest("table")[0].id;
    //debugger;
    var recordPerPage;
    var selectedPageNo = '';
    var columnIndex = _this.sorttable_columnindex;
    var sortedColumnClassName = _this.className;

    if (_selectedPageNo && _recordPerPage) {
        recordPerPage = _recordPerPage;
        selectedPageNo = _selectedPageNo;
        pagination(tableId, selectedPageNo, recordPerPage);
    }
    else {
        var $ddlPagination = $($("#" + tableId).parent()).find("select#ddlPagination");
        if ($ddlPagination.length > 0) {
            recordPerPage = $ddlPagination.val();
            selectedPageNo = $($("#" + tableId).parent()).find('#paginationNumbers').find('span.active').text();

            pagination(tableId, '', recordPerPage, 'true');
        }
    }
    //debugger;
    gridPaginationSorting(tableId, selectedPageNo, recordPerPage, columnIndex, sortedColumnClassName);


}
/* ******************************************************************
   Supporting functions: bundled here to avoid depending on a library
   ****************************************************************** */


/* for Mozilla/Opera9 */
if (document.addEventListener) {
    document.addEventListener("DOMContentLoaded", sorttable.init, false);
}

/* for Internet Explorer */
/*@cc_on @*/
/*@if (@_win32)
    document.write("<script id=__ie_onload defer src=javascript:void(0)><\/script>");
    var script = document.getElementById("__ie_onload");
    script.onreadystatechange = function() {
        if (this.readyState == "complete") {
            sorttable.init(); // call the onload handler
        }
    };
/*@end @*/

/* for Safari */
if (/WebKit/i.test(navigator.userAgent)) { // sniff
    var _timer = setInterval(function () {
        if (/loaded|complete/.test(document.readyState)) {
            sorttable.init(); // call the onload handler
        }
    }, 10);
}

/* for other browsers */
window.onload = sorttable.init;

$(document).ready(function () {
    forEach(document.getElementsByTagName('table'), function (table) {
        if (table.className.search(/\bsortable\b/) != -1) {

            var gridSortableValues = $("input[name*='hdnGridSortable']").val();
            var gridPaginationableValues = $("input[name*='hdnGridPaginationable']").val();

            //debugger;
            if (gridSortableValues && !gridPaginationableValues) {
                //debugger;
                var objGridSortableValues = jQuery.parseJSON(gridSortableValues);
                if (table.id == objGridSortableValues.gridName) {
                    sortTableCustom(table, objGridSortableValues.sortColumn, objGridSortableValues.sortDirection, '', '');
                }
                return;
            }
            else if (gridPaginationableValues && !gridSortableValues) {
                //debugger;
                var objGridPaginationableValues = jQuery.parseJSON(gridPaginationableValues);
                if (table.id == objGridPaginationableValues.gridName) {
                    pagination(table.id, objGridPaginationableValues.gridPagination, objGridPaginationableValues.gridRecordsPerPage);
                    //sortTableCustom(table, objGridPaginationableValues.gridPagination, objGridPaginationableValues.gridRecordsPerPage);
                }
                return;
            }
            else if (gridPaginationableValues && gridSortableValues) {
                var objGridPaginationableValues = jQuery.parseJSON(gridPaginationableValues);
                var objGridSortableValues = jQuery.parseJSON(gridSortableValues);
                //debugger;
                if (table.id == objGridPaginationableValues.gridName && table.id == objGridSortableValues.gridName) {
                    sortTableCustom(table, objGridSortableValues.sortColumn, objGridSortableValues.sortDirection, objGridPaginationableValues.gridPagination, objGridPaginationableValues.gridRecordsPerPage);
                }
                return;
            } else if (!gridPaginationableValues && !gridSortableValues) {
                //debugger;
                pagination(table.id, '', 10);
            }


        }
    });

});






function dean_addEvent(element, type, handler) {
    if (element.addEventListener) {
        element.addEventListener(type, handler, false);
    } else {
        // assign each event handler a unique ID
        if (!handler.$$guid) handler.$$guid = dean_addEvent.guid++;
        // create a hash table of event types for the element
        if (!element.events) element.events = {};
        // create a hash table of event handlers for each element/event pair
        var handlers = element.events[type];
        if (!handlers) {
            handlers = element.events[type] = {};
            // store the existing event handler (if there is one)
            if (element["on" + type]) {
                handlers[0] = element["on" + type];
            }
        }
        // store the event handler in the hash table
        handlers[handler.$$guid] = handler;
        // assign a global event handler to do all the work
        element["on" + type] = handleEvent;
        //alert("sorting done");
    }
};
// a counter used to create unique IDs
dean_addEvent.guid = 1;

function removeEvent(element, type, handler) {
    if (element.removeEventListener) {
        element.removeEventListener(type, handler, false);
    } else {
        // delete the event handler from the hash table
        if (element.events && element.events[type]) {
            delete element.events[type][handler.$$guid];
        }
    }
};

function handleEvent(event) {
    var returnValue = true;
    // grab the event object (IE uses a global event object)
    event = event || fixEvent(((this.ownerDocument || this.document || this).parentWindow || window).event);
    // get a reference to the hash table of event handlers
    var handlers = this.events[event.type];
    // execute each event handler
    for (var i in handlers) {
        this.$$handleEvent = handlers[i];
        if (this.$$handleEvent(event) === false) {
            returnValue = false;
        }
    }
    return returnValue;
};

function fixEvent(event) {
    // add W3C standard event methods
    event.preventDefault = fixEvent.preventDefault;
    event.stopPropagation = fixEvent.stopPropagation;
    return event;
};
fixEvent.preventDefault = function () {
    this.returnValue = false;
};
fixEvent.stopPropagation = function () {
    this.cancelBubble = true;
}

// Dean's forEach: http://dean.edwards.name/base/forEach.js
/*
    forEach, version 1.0
    Copyright 2006, Dean Edwards
    License: http://www.opensource.org/licenses/mit-license.php
*/

// array-like enumeration
if (!Array.forEach) { // mozilla already supports this
    Array.forEach = function (array, block, context) {
        for (var i = 0; i < array.length; i++) {
            block.call(context, array[i], i, array);
        }
    };
}

// generic enumeration
Function.prototype.forEach = function (object, block, context) {
    for (var key in object) {
        if (typeof this.prototype[key] == "undefined") {
            block.call(context, object[key], key, object);
        }
    }
};

// character enumeration
String.forEach = function (string, block, context) {
    Array.forEach(string.split(""), function (chr, index) {
        block.call(context, chr, index, string);
    });
};

// globally resolve forEach enumeration
var forEach = function (object, block, context) {
    if (object) {
        var resolve = Object; // default
        if (object instanceof Function) {
            // functions have a "length" property
            resolve = Function;
        } else if (object.forEach instanceof Function) {
            // the object implements a custom forEach method so use that
            object.forEach(block, context);
            return;
        } else if (typeof object == "string") {
            // the object is a string
            resolve = String;
        } else if (typeof object.length == "number") {
            // the object is array-like
            resolve = Array;
        }
        resolve.forEach(object, block, context);
    }
};